#!/bin/sh
/opt/ss/ss-server -c /opt/ss/ss.json </dev/null 2>&1 | /usr/bin/logger -it 'ss-server' &
